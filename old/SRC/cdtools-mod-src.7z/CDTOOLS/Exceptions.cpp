#include <malloc.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stddef.h>
#ifdef HAVE_GLIB
#include <glib.h>
#endif
#ifdef DEBUG
#include <iostream>
#endif
#include "String.h"
#include "Exceptions.h"
#include "generic.h"
#ifdef HAVE_CONFIG_H
#include "config.h"
#else
#define _(x) x
#endif

char GeneralException::t[BUFSIZ];

GeneralException::GeneralException(String emsg) : msg(emsg.strdup()) {
#ifdef DEBUG
    cerr << _("Generating a General Exception error: '") << msg << "'.\n";
#endif
}
GeneralException::GeneralException() : msg(0) {
#ifdef DEBUG
    cerr << _("Generating a General Exception error: '") << msg << "'.\n";
#endif
}
GeneralException::GeneralException(const GeneralException & e) : msg(strdup(e.msg)) {
#ifdef DEBUG
    cerr << _("Generating a General Exception error: '") << msg << "'.\n";
#endif
}

GeneralException::~GeneralException() {
    free(msg);
}

TaskNotFound::TaskNotFound() : GeneralException("Task not found") { }

const char * GeneralException::GetMsg() const {
    return msg;
}

MemoryException::MemoryException(ssize_t s) {
    sprintf(t, _("Failed allocating %u bytes."), (unsigned int)s);
    msg = strdup(t);
}

IOException::IOException(String fn, op_t op, ssize_t s) {
    sprintf(t, _("An error has occured while %s %u bytes on %s: %s"), op == IO_WRITE ? _("writing") : _("reading"),
	    s, fn.to_charp(), strerror(errno));
    msg = strdup(t);
}

IOGeneral::IOGeneral(String fn) : GeneralException(fn) { }

IOGeneral::IOGeneral() { }

IOAgain::IOAgain() : IOGeneral(_("No more bytes for reading or writing.")) {
#ifdef DEBUG
    cerr << "Generating an IOAgain exception: '" << GetMsg() << "'.\n";
#endif
}

TaskSwitch::TaskSwitch() : GeneralException(_("Switching task in a non-tasked environnement")) {
#ifdef DEBUG
    cerr << "Generating a TaskSwitch exception: '" << GetMsg() << "'.\n";
#endif
}

Exit::Exit(int a_code) : GeneralException(_("Exitting with code " + a_code)), code(a_code) {
#ifdef DEBUG
    cerr << "Generating an Exit exception: '" << GetMsg() << "'.\n";
#endif
}

int Exit::GetCode() {
    return code;
}

char * xstrdup(const char * s) {
    char * r;

    r = (char *) xmalloc(strlen(s) + 1);
    strcpy(r, s);
    return r;
}

void * xmalloc(size_t s) throw (GeneralException) {
    char * r;

    if (!s) {
	return 0;
    }

    if (!(r = (char *) ::malloc(s))) {
	throw MemoryException(s);
    }
#ifdef DEBUG
    fprintf(stderr, "Allocating %i bytes of memory, got it at %p\n", s, r);
#endif

    memset(r, 0, s);

    return (void *)(r);
}

void * xrealloc(void * ptr, size_t s) {
#ifdef DEBUG
    void * r = realloc(ptr, s);
    fprintf(stderr, "Reallocating pointer at %p for %i bytes, now at %p\n", ptr, s, r);
    return r;
#else
    return realloc(ptr, s);
#endif
}

void xfree(char *& p) {
#ifdef DEBUG
    fprintf(stderr, "Freeing pointer at %p\n", p);
#endif
    if (p) {
	::free(p);
	p = 0;
    }
}


void xfree(char * p) {
#ifdef DEBUG
    fprintf(stderr, "Freeing pointer at %p\n", p);
#endif
    if (p) {
	::free(p);
	p = 0;
    }
}
void xfree(void *& p) {
    xfree(((char *)p));
}

void xfree(unsigned char *& p) {
    xfree(((char *)p));
}

int xpipe(int * p, int flag) throw (GeneralException) {
    //if (pipe(p)) {
	if (1) {
	throw GeneralException(String(_("Error creating pipe: ")) + strerror(errno));
    }

    return p[flag];
}

pid_t xfork() throw (GeneralException) {
    pid_t p;

    //p = fork();

    if (p == -1) {
	throw GeneralException(_("Was not able to fork().\n"));
    }

    return p;
}

void xexit(int status) throw (GeneralException) {
    throw Exit(status);
}
