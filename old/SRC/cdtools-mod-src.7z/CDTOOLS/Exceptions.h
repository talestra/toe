#ifndef __EXCEPTIONS_H__
#define __EXCEPTIONS_H__
#ifdef __cplusplus
//#pragma warning(disable:4290)
//#pragma warning(disable:4267)
//#pragma warning(disable:4311)
//#pragma warning(disable:4244)

#include <process.h>
#include <io.h>
#include <stdio.h>
#include <unistd.h>
#include <stddef.h>
#include <string.h>
#include <stdlib.h>

//#define __inline__ inline
#define INLINE __inline__
//#define ssize_t size_t
//#define pid_t int

class Base {
  public:
    static char * strdup(const char * s);
    static void * malloc(ssize_t s);
    static void * realloc(void * p, size_t s);
    static void * calloc(size_t n, size_t s);
    void * operator new(size_t s);
    void * operator new(size_t s, void * p);
    void operator delete(void * p);
    static void free(void *& p);
    static void free(char *& p);
    static void free(unsigned char *& p);
    static int pipe(int * p, int flag = 0);
    static pid_t fork();
    static void exit(int);
};

class String;

class GeneralException : public Base {
  public:
      GeneralException(String);
      GeneralException(const GeneralException &);
      ~GeneralException();
    const char * GetMsg() const;

  protected:
      GeneralException();
    char * msg;
    static char t[BUFSIZ];
};

char * xstrdup(const char *);
void * xmalloc(size_t) throw (GeneralException);
void xfree(void *&);
void xfree(char *&);
void xfree(unsigned char *&);
void * xrealloc(void *, size_t);
int xpipe(int *, int = 0) throw (GeneralException);
pid_t xfork() throw (GeneralException);
void xexit(int) throw (GeneralException);

INLINE char * Base::strdup(const char * s) {
    return xstrdup(s);
}

INLINE void * Base::malloc(ssize_t s) {
    return xmalloc(s);
}

INLINE void * Base::realloc(void * p, size_t s) {
    return xrealloc(p, s);
}

INLINE void * Base::calloc(size_t n, size_t s) {
    return xmalloc(n * s);
}

INLINE void * Base::operator new(size_t s) {
    return xmalloc(s);
}

INLINE void * Base::operator new(size_t s, void * p) {
    return memset(p, 0, s);
}

INLINE void Base::operator delete(void * p) {
    xfree(p);
}

INLINE void Base::free(void *& p) {
    xfree(p);
}

INLINE void Base::free(char *& p) {
    xfree(p);
}

INLINE void Base::free(unsigned char *& p) {
    xfree(p);
}

INLINE int Base::pipe(int * p, int flag) {
    return xpipe(p, flag);
}

INLINE pid_t Base::fork() {
    return xfork();
}

INLINE void Base::exit(int status) {
    xexit(status);
}

class MemoryException : public GeneralException {
  public:
      MemoryException(ssize_t);
};

class TaskNotFound : public GeneralException {
  public:
      TaskNotFound();
};

enum op_t {
  IO_WRITE = 1,
  IO_READ
};

class IOGeneral : public GeneralException {
  public:
      IOGeneral(String);
  protected:
      IOGeneral();
};

class IOException : public IOGeneral {
  public:
      IOException(String, op_t, ssize_t);
};

class IOAgain : public IOGeneral {
  public:
      IOAgain();
};

class TaskSwitch : public GeneralException {
  public:
      TaskSwitch();
};

class Exit : public GeneralException {
  public:
      Exit(int);
      int GetCode();
  private:
    int code;
};

#include <String.h>

#else
#error This only works with a C++ compiler
#endif
#endif
