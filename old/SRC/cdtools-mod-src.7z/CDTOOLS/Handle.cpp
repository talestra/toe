#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include "Handle.h"
#include <sys/types.h>
#include <time.h>

#ifdef HAVE_CONFIG_H
#include "config.h"
#else
#define _(x) x
#endif

Handle::Handle(const Handle & nh) : itell(0), h(nh.h >= 0 ? dup(nh.h) : nh.h), closed(nh.closed), nonblock(nh.closed)
#ifdef HAVE_ZLIB
, zfile(0), z(0)
#endif
{
//    cerr << "Duplication of handle " << nh.h << " to " << h << endl;
#ifdef HAVE_ZLIB
    if ((h >= 0) && (nh.z)) {
	SetZ(nh.z);
    }
#endif
}

Handle::~Handle() {
//    cerr << "Destroying handle " << h << endl;
    close();
}

Handle::Handle(int nh) : h(nh), closed(false), nonblock(false)
#ifdef HAVE_ZLIB
, zfile(0), z(0)
#endif
{
//    cerr << "Initialising handle " << h << endl;
}

int Handle::GetHandle() {
    return h;
}

int Handle::GetHandle() const {
    return h;
}

ssize_t Handle::write(const void *buf, size_t count) throw (GeneralException) {
    ssize_t r, tr = 0;
    bool done, full = false;

    do {
	done = true;
	errno = 0;
        if ((r = uwrite(buf, count)) < 0) {
    	    if ((!errno) || (errno == EAGAIN) || (errno == EINTR)) {
		// Avant de d�clarer une erreur, on v�rifie si ce n'est pas un
		// probl�me li� au fait qu'il n'y a plus de place libre. Cela peut
		// arriver si l'on agit sur un pipe ou un handle. Nous
		// attendons encore une fois avant de d�clarer l'erreur,
		// grace au drapeau full.
		if (full) {
		    throw IOException(GetName(), IO_WRITE, count);
		} else {
		    done = false;
		    full = true;
		    if (nonblock) {
//			cerr << "write: throwing IOAgain for handle " << GetName() << endl;
			throw IOAgain();
		    } else {
				_sleep(1);
		    }
		}
	    } else {
		throw IOException(GetName(), IO_WRITE, count);
	    }
	} else if (((size_t) r) != count) {
	    if (nonblock) {
		return r;
	    }
	    full = done = false;
	    //((char *)buf) += r;
	    //((char *)buf) = ((int)(char *)buf) + r;
	    buf = (void *)((int)buf + r);
	    tr += r;
	}
    } while (!done);

    return r + tr;
}

ssize_t Handle::read(void *buf, size_t count) throw (GeneralException) {
    ssize_t r;

    errno = 0;

    //printf("1");

    /*
    int ptell = tell();

    r = uread(buf, count);

    printf("0: %d ; P: %d ; S: %d\n", ptell, count, r);

    //printf("READ: %d\n", r); _sleep(5);

    if (r < 0) r = 0;

    if (!r) close();

    return r;
    */

    while ((r = uread(buf, count)) < 0) {
	if ((!errno) || (errno == EAGAIN) || (errno == EINTR)) {
	    // Avant de d�clarer une erreur, on v�rifie si ce n'est pas un
	    // probl�me li� au fait qu'il n'y a plus d'octets.
	    if (nonblock) {
		//cerr << "read: throwing IOAgain for handle " << GetName() << endl;
			throw IOAgain();
		//printf("[%d]\n", errno);
	    }
	} else {
		//printf("[%d]\n", errno);
	    throw IOException(GetName(), IO_READ, count);
	    break;
	}
    }

    //printf("2");

    if (!r) {
	close();
    }

    return r;
}

bool Handle::IsClosed(void) const {
    return closed;
}

bool Handle::IsNonBlock(void) const {
    return nonblock;
}

void Handle::SetNonBlock(void) {
    if ((h >= 0) || !nonblock) {
		//fcntl(h, F_SETFL, O_NONBLOCK);
    }
    nonblock = true;
}

Handle & operator<<(Handle & h, const String & s) {
    const char * p;

    p = s.to_charp();
    h.write(p, strlen(p));

    return h;
}

Handle & operator>>(Handle & h, String & s) {
    char t[BUFSIZ];
    int i = 0, r;

    while ((r = h.read(&(t[i]), 1)) && (i != (BUFSIZ - 1))) {
	// Il y a souvent des \r\n dans les sockets par exemple,
	// ou bien en lisant des fichiers au format MS-DOS. On
	// ignore le \r pour ne garder que le \n, standard sous Unix.
	if (t[i] == '\r') {
	    continue;
	}
	if (t[i] == '\n') {
	    break;
	} else {
	    i++;
	}
    }

    t[i] = '\0';
    s = t;
    return h;
}

void Handle::close() throw (GeneralException) {
    if (IsClosed()) return;

    if (h >= 0) {
#ifdef HAVE_ZLIB
	if (z) {
//	    cerr << "Performing gzclose on handle " << h << endl;
	    int err = gzclose(zfile);
//	    cerr << "gzclose returned " << err << endl;
	    if (err) {
		if (err == Z_ERRNO) {
		    throw GeneralException(String(_("Error during close: ")) + strerror(errno));
		} else {
		    throw GeneralException(_("Error in zlib during gzclose."));
		}
	    }
	} else {
#else
	{
#endif
	    int err = ::close(h);
	    if (err) throw GeneralException(String(_("Error during close: ")) + strerror(errno));
	}
    }

    h = -1;

    closed = 1;
}

bool Handle::CanRead(void) const {
    return false;
}

bool Handle::CanWrite(void) const {
    return false;
}

String Handle::GetName(void) const {
    return _("Bare Handle - should not happend");
}

ssize_t Handle::GetSize(void) const {
    return -1;
}

time_t Handle::GetModif(void) const {
    return -1;
}

bool Handle::CanWatch(void) const {
    return true;
}

void Handle::Dup(const Handle & H) {
    close();
    if (H.h >= 0) {
	h = dup(H.h);
    }
}

#ifdef HAVE_ZLIB
void Handle::SetZ(int az) throw (GeneralException) {
    if (z) {
	throw GeneralException(_("Can't SetZ a Handle twice."));
    }
    if (h < 0) {
	throw GeneralException(_("Can't SetZ a virtual Handle."));
    }
    if (az) {
	char format[4];
	int index = 0;
	if (CanRead()) {
	    format[index++] = 'r';
	}
	if (CanWrite()) {
	    format[index++] = 'w';
	}
	format[index++] = (char) (az + '0');
	format[index] = 0;
//	cerr << "Performing gzdopen on handle " << h << " with mode \"" << format << "\"\n";
	if (!(zfile = gzdopen(h, format))) {
	    throw GeneralException(_("Was not able to gzdopen."));
	}
	z = az;
    }
}
#endif

ssize_t Handle::uwrite(const void * buf, size_t count) throw (GeneralException) {
#ifdef HAVE_ZLIB
    if (z) {
	itell += count;
//	cerr << "Performing gzwrite of " << count << " byte for handle " << h << endl;
#ifdef HAVE_CLEAN_ZLIB
	int err = gzwrite(zfile, buf, count);
#else
	int err = gzwrite(zfile, (char *) buf, count);
#endif
//	cerr << "gzwrite returned " << err << endl;
	if (err == 0) {
	    const char * m = gzerror(zfile, &err);
	    if (err == Z_ERRNO) {
		return -1;
	    } else {
		throw GeneralException(String(_("Error in zlib during gzwrite: ")) + m);
	    }
	}
	return err;
    } else {
#else
    {
#endif
	itell += count = ::write(h, buf, count);
	return count;
    }
}

ssize_t Handle::uread(void * buf, size_t count) {
	itell += count = ::read(h, buf, count);
	return count;
}

off_t Handle::tell() const {
    return itell;
}

bool Handle::CanSeek() const {
    return 0;
}

off_t Handle::seek(off_t, int) throw(GeneralException) {
    throw IOGeneral("Handle " + GetName() + " can't seek");
}

void copy(Handle * s, Handle * d, ssize_t size) {
    long i;
    unsigned char c;
    long r;

    for (i = 0; (i < size) || (size < 0); i++) {
	r = s->read(&c, 1);
	if (r == 0) {
	    break;
	}
	d->write(&c, 1);
    }
}
