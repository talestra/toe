#ifndef __HANDLE_H__
#define __HANDLE_H__
#ifdef __cplusplus

#ifdef HAVE_ZLIB
#include <zlib.h>
#endif

#include <unistd.h>
#include <iostream>
#include "String.h"
#include "Exceptions.h"

#include <sys/types.h>
#include <time.h>

class Handle : public Base {
  public:
      Handle(const Handle &);
      virtual ~Handle();
    virtual ssize_t read(void *buf, size_t count) throw (GeneralException);
    virtual ssize_t write(const void *buf, size_t count) throw (GeneralException);
    bool IsClosed(void) const;
    bool IsNonBlock(void) const;
    void SetNonBlock(void);
    virtual bool CanRead() const;
    virtual bool CanWrite() const;
    virtual bool CanSeek() const;
    virtual off_t seek(off_t, int = SEEK_SET) throw (GeneralException);
    virtual off_t tell() const;
    virtual String GetName() const;
    virtual ssize_t GetSize() const;
    virtual time_t GetModif() const;
    void close() throw (GeneralException);
    int GetHandle();
    virtual bool CanWatch() const;
    virtual void Dup(const Handle &);
#ifdef HAVE_ZLIB
    virtual void SetZ(int = 9) throw (GeneralException);
#endif
  protected:
      Handle(int h);
    int GetHandle() const;
    off_t itell;
  private:
    ssize_t uwrite(const void *, size_t) throw (GeneralException);
    ssize_t uread(void *, size_t);
    int h;
    bool closed, nonblock;
#ifdef HAVE_ZLIB
    gzFile zfile;
    int z;
#endif
};

Handle & operator<<(Handle &, const String &);
Handle & operator>>(Handle &, String &);

void copy(Handle *, Handle *, ssize_t = -1);

#else
#error This only works with a C++ compiler
#endif
#endif
