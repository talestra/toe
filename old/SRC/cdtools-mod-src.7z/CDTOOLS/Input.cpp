#pragma PACK(1)

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "Input.h"
#include "Exceptions.h"
#ifdef HAVE_CONFIG_H
#include "config.h"
#else
#define _(x) x
#endif
Input::Input(const String & no) throw (GeneralException) :
    Handle(no.strlen() ? open(no.to_charp(), O_RDONLY | O_BINARY, 0777) : dup(0)),
    n(no) {

#ifdef DEBUG
    fprintf(stderr, "Opening file %s, Input at %p\n", no.to_charp(), this);
#endif

    if (GetHandle() < 0) {
	throw IOGeneral(String(_("Error opening file ")) + no + _(" for reading: ") + strerror(errno));
    }

    struct stat s;
    fstat(GetHandle(), &s);
    date_modif = s.st_mtime;

    if (S_ISREG(s.st_mode)) {
		size = seek(0, SEEK_END);
		seek(0, SEEK_SET);
		//printf("%d\n", size); exit(-1);
    }
}

Input::Input(const Input & i) : Handle(i), n(i.n), size(i.size), date_modif(i.date_modif) {
}

bool    Input::CanWrite() const { return 0; }
bool    Input::CanRead () const { return 1; }
bool    Input::CanSeek () const { struct stat s; fstat(GetHandle(), &s); return S_ISREG(s.st_mode); }
String  Input::GetName () const { return n; }
ssize_t Input::GetSize () const { return size; }
time_t  Input::GetModif() const { return date_modif; }
off_t Input::seek(off_t offset, int whence) throw (GeneralException) {
    if ((itell = lseek(GetHandle(), offset, whence)) < 0) {
	throw IOGeneral(String(_("Error seeking file ")) + GetName() + _(": ") + strerror(errno));
    }
/*#ifdef PARANOID_SEEK
    if (itell != lseek(GetHandle(), 0, SEEK_CUR)) {
	throw IOGeneral(String(_("Error seeking file ")) + GetName() + _(": the position does not match"));
    }
#endif*/
    return itell;
}

Stdin_t::Stdin_t() { }

bool Stdin_t::CanSeek() const {
    return 0;
}

String Stdin_t::GetName() const {
    return "Stdin";
}

Stdin_t Stdin;
