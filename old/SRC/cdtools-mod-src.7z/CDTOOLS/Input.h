#ifndef __INPUT_H__
#define __INPUT_H__
#ifdef __cplusplus

//#include <sys/types.h>
//#include <time.h>
#include "String.h"
#include "Handle.h"

class Input : public Handle {
  public:
      Input(const String & = "") throw (GeneralException);
      Input(const Input &);
      virtual ~Input() {}
    virtual bool CanWrite() const;
    virtual bool CanRead() const;
    virtual bool CanSeek() const;
    virtual off_t seek(off_t, int = SEEK_SET) throw (GeneralException);
    virtual String GetName() const;
    virtual ssize_t GetSize() const;
    virtual time_t GetModif() const;

  protected:
    String n;
    off_t size;
    time_t date_modif;
};

class Stdin_t : public Input {
  public:
      Stdin_t();
      virtual ~Stdin_t() {}
    virtual bool CanSeek() const;
    virtual String GetName() const;
};

extern Stdin_t Stdin;

#else
#error This only works with a C++ compiler
#endif
#endif
