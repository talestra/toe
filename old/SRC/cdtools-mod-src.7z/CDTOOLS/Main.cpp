#include "Main.h"
#include "generic.h"
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

Main::Main() : setted(false) {}

Main::~Main() {}

extern Main * Application;

void Main::set_args(int a_argc, char ** a_argv, char ** a_enve) {
    if (setted) {
	return;
    }
    argc = a_argc;
    argv = a_argv;
    enve = a_enve;
    setted = true;
}

int main(int argc, char ** argv, char ** enve) {
    int r;
    
    try {
	Application->set_args(argc, argv, enve);
	r = Application->startup();
    }
    catch (Exit e) {
	r = e.GetCode();
    }
    catch (GeneralException e) {
	printm(M_ERROR, "The application caused an exception: %s\n", e.GetMsg());
	delete Application;
	exit(-1);
    }
    catch (...) {
	printm(M_ERROR, "The application caused an unknow exception\n");
	delete Application;
	exit(-1);
    }
    delete Application;
    exit(r);
}
