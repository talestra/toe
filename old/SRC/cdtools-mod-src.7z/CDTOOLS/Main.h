#ifndef __MAIN_H__
#define __MAIN_H__

#include "Exceptions.h"

class Main : public Base {
  public:
      Main();
      virtual ~Main();
    virtual int startup() throw (GeneralException) = 0;
  protected:
    void set_args(int, char **, char **);
    int argc;
    char ** argv;
    char ** enve;
    bool setted;
    
    friend int main(int, char **, char **);
};

#define CODE_BEGINS class Appli : public Main {
#define CODE_ENDS } * Application = new Appli();

#endif
