#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "Output.h"
#include "Exceptions.h"
#ifdef HAVE_CONFIG_H
#include "config.h"
#else
#define _(x) x
#endif

Output::Output(String no, int create, int trunc) throw (GeneralException) :
    Handle(no.strlen() ? open(no.to_charp(), O_WRONLY | O_BINARY | (O_CREAT * (create ? 1 : 0)) | (O_TRUNC * (trunc ? 1 : 0))
, 0777
) : dup(1)),
    n(no) {
    if (GetHandle() < 0) {
	throw IOGeneral(String(_("Error opening file ")) + no + _(" for writing: ") + strerror(errno));
    }

    size = lseek(GetHandle(), 0, SEEK_END);
    lseek(GetHandle(), 0, SEEK_SET);

    struct stat s;

    fstat(GetHandle(), &s);

    date_modif = s.st_mtime;
}

Output::Output(const Output & o) : Handle(o), n(o.n) {
}

bool Output::CanWrite() const {
    return 1;
}

bool Output::CanRead() const {
    return 0;
}

bool Output::CanSeek() const {
    struct stat s;

    fstat(GetHandle(), &s);

    return S_ISREG(s.st_mode);
}

off_t Output::seek(off_t offset, int whence) throw (GeneralException) {
    if ((itell = lseek(GetHandle(), offset, whence)) < 0) {
	throw IOGeneral(String(_("Error seeking file ")) + n + _(": ") + strerror(errno));
    }
#ifdef PARANOID_SEEK
    if (itell != lseek(GetHandle(), 0, SEEK_CUR)) {
	throw IOGeneral(String(_("Error seeking file ")) + n + _(": the position does not match"));
    }
#endif
    return itell;
}

String Output::GetName() const {
    return n;
}

Stdout_t::Stdout_t() {}

bool Stdout_t::CanSeek() const {
    return 0;
}

String Stdout_t::GetName() const {
    return "Stdout";
}

Stderr_t::Stderr_t() : Handle(dup(2)) {}

bool Stderr_t::CanWrite() const {
    return 1;
}

bool Stderr_t::CanRead() const {
    return 0;
}

bool Stderr_t::CanSeek() const {
    return 0;
}

String Stderr_t::GetName() const {
    return "Stderr";
}

Stdout_t Stdout;
Stderr_t Stderr;
