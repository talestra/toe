#ifndef __OUTPUT_H__
#define __OUTPUT_H__
#ifdef __cplusplus

#include <sys/types.h>
#include <time.h>
#include "String.h"
#include "Handle.h"

class Output : public Handle {
  public:
      Output(String = "", int create = 1, int trunc = 1) throw (GeneralException);
      Output(const Output &);
      virtual ~Output() {}
    virtual bool CanWrite() const;
    virtual bool CanRead() const;
    virtual bool CanSeek() const;
    virtual off_t seek(off_t, int = SEEK_SET) throw (GeneralException);
    virtual String GetName() const;

  protected:
    String n;
    off_t size;
    time_t date_modif;
};

class Stdout_t : public Output {
  public:
      Stdout_t();
      virtual ~Stdout_t() {}
    virtual bool CanSeek() const;
    virtual String GetName() const;
};

class Stderr_t : public Handle {
  public:
      Stderr_t();
      virtual ~Stderr_t() {}
    virtual bool CanWrite() const;
    virtual bool CanRead() const;
    virtual bool CanSeek() const;
    virtual String GetName() const;
};

extern Stdout_t Stdout;
extern Stderr_t Stderr;

#else
#error This only works with a C++ compiler
#endif
#endif
