#ifndef __STRING_H__
#define __STRING_H__
#ifdef __cplusplus

#include <iostream>
#include <string.h>
#include "Exceptions.h"

class String : public Base {
  public:
      String(const String &);
      String(const char * = "");
#if 0
      String(const char * = "", ...);
#endif
      String(char);
      String(int);
      String(unsigned int);
#ifdef USE_LONGLONG
      String(long long);
      String(unsigned long long);
#endif
      String(double);
      ~String();
    const char * set(const char *, ...);
    const char * set(const String &, ...);
    const char * to_charp(size_t = 0, ssize_t = -1) const;
    String extract(size_t = 0, ssize_t = -1) const;
    char * strdup(size_t = 0, ssize_t = -1) const;
    int to_int() const;
    double to_double() const;
    String to_sqldate() const;
    String to_sqltime() const;
    String from_sqldate() const;
    String from_sqltime() const;
    double datedif(const String &) const;
    bool is_date() const;
    bool is_number() const;
    bool is_float() const;
    bool is_time() const;
    size_t strlen() const;
    ssize_t strchr(char, size_t = 0) const;
    ssize_t strrchr(char) const;
    ssize_t strstr(const String &) const;
    int strchrcnt(char) const;
    String & operator=(const String &);
    String operator+(const String &) const;
    String & operator+=(const String &);
    bool operator!=(const String &) const;
    bool operator==(const String &) const;
    bool operator<=(const String &) const;
    bool operator>=(const String &) const;
    bool operator<(const String &) const;
    bool operator>(const String &) const;
    char operator[](size_t i) const;
    String & toupper();
    String & tolower();
    String & rtrim();

  private:
      String(int hs, const char *);
    static char t[];
    char * str;
    size_t siz;
};

std::ostream & operator<<(std::ostream &, const String &);
std::istream & operator>>(std::istream &, String &);

String operator+(const char *, const String &);

#else
#error This only works with a C++ compiler
#endif
#endif
