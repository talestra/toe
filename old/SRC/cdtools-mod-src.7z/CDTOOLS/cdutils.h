/*
 *  PSX-Tools Bundle Pack
 *  Copyright (C) 2002-2003 Nicolas "Pixel" Noble
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/* $Id: cdutils.h,v 1.20 2006/07/17 16:10:07 pixel Exp $ */

#ifndef __CDUTILS_H__
#define __CDUTILS_H__

#include "yazedc.h"
#include "generic.h"

#include "Handle.h"

#define MODE0 0
#define MODE1 1
#define MODE2 2
#define MODE2_FORM1 3
#define MODE2_FORM2 4
#define MODE_RAW 5
#define GUESS 6

extern const long sec_sizes[];
extern const long sec_offsts[];
extern const String sec_modes[];

#ifdef _MSC_VER
#pragma pack(1)
#endif

#pragma pack(1)

class cdutils : public Base {
  public:
      cdutils(Handle * f_iso_r, Handle * f_iso_w = 0);
      virtual ~cdutils();
#ifdef _MSC_VER
#pragma pack(push)
#pragma pack(1)
#endif
    struct DirEntry {
	unsigned char R;
	unsigned char NExt;
	unsigned long Sector;
	unsigned long BESector;
	unsigned long Size;
	unsigned long BESize;
	unsigned char Year;
	unsigned char Month;
	unsigned char Day;
	unsigned char Hour;
	unsigned char Minute;
	unsigned char Second;
	unsigned char Offset;
	unsigned char Flags;
	unsigned char HandleUnit;
	unsigned char HandleGap;
	unsigned short VolSeq;
	unsigned short BEVolSeq;
	unsigned char N;
	char id[1];
    } PACKED;
#ifdef _MSC_VER
#pragma pack(pop)
#endif

    struct DirEntry * rootDir;

    Handle * open_ppf(String ppf, String comment) throw(GeneralException);
    void close_ppf() throw(GeneralException);
    void set_iso_w(Handle *);
    static Uint16 swap_word(Uint16 i);
    static Uint32 swap_dword(Uint32 i);
    static Uint16 from_LE16(Uint16 i);
    static Uint32 from_LE32(Uint32 i);
    static Uint16 from_BE16(Uint16 i);
    static Uint32 from_BE32(Uint32 i);
    static Uint16 to_LE16(Uint16 i) { return from_LE16(i); }
    static Uint32 to_LE32(Uint32 i) { return from_LE32(i); }
    static Uint16 to_BE16(Uint16 i) { return from_BE16(i); }
    static Uint32 to_BE32(Uint32 i) { return from_BE32(i); }
    int guess_type(int number = -1);
    void sector_seek(long sector);
    long read_sector(Byte * buffer, int type = GUESS, int number = -1);
    void read_data(Byte * buffer, long size, int type = GUESS, int number = -1);
    void read_file(Handle * Handle, long size, int type = GUESS, int number = -1);
    void write_sector(Byte * buffer, int type = GUESS, int number = -1) throw (GeneralException);
    void write_data(Byte * buffer, long size, int type = GUESS, int number = -1);
    void write_file(Handle * Handle, long size = -1, int type = GUESS, int number = -1);
    void create_sector(int type, int number, bool eof = false) throw (GeneralException);
    int get_iso_infos();
    int show_iso_infos();
    int get_pt_infos();
    int show_pt_infos();
    struct DirEntry find_path(String path);
    struct DirEntry find_parent(String path);
    struct DirEntry * find_path(Byte ** buffer, String path);
    struct DirEntry * find_parent(Byte ** buffer, String path);
    void show_head_entry(void);
    int show_entry(struct DirEntry * dir);
    int show_dir(struct DirEntry * dir);
    struct DirEntry find_dir_entry(struct DirEntry * dir, String name);
    struct DirEntry * find_dir_entry(Byte ** buffer, struct DirEntry * dir, String name);
    static unsigned char from_BCD(unsigned char x);
    static unsigned char to_BCD(unsigned char x);
    static bool is_valid_BCD(unsigned char x);
    static unsigned long from_MSF(unsigned long msf, unsigned long start = 150);
    static unsigned long from_MSF(unsigned char m, unsigned char s, unsigned char f, unsigned long start = 150);
    static unsigned long to_MSF(int sect, unsigned long start = 150);
    static void to_MSF(int sect, unsigned char & m, unsigned char & s, unsigned char & f, unsigned long start = 150);
  private:
    void write_ppf(Byte * old_sec, Byte * new_sec, int sec_num);
    String format_date(String input);
    yazedc yazedc_o;

    Handle * f_iso_r, * f_iso_w, * ppf_file;
    int pt1, pt2, snum, ptl, root;
};

class cdfile : public Handle {
  public:
      cdfile(cdutils *, const cdutils::DirEntry *, int = GUESS);
      cdfile(cdutils *, int sector, ssize_t = -1, int = GUESS);
      virtual ~cdfile();
    virtual ssize_t read(void *buf, size_t count) throw (GeneralException);
    virtual bool CanRead() const;
    virtual String GetName() const;
    virtual bool CanWatch() const;
    virtual ssize_t GetSize() const;
    virtual bool CanSeek() const;
    virtual off_t seek(off_t, int = SEEK_SET) throw (GeneralException);
  private:
    cdutils * cd;
    int sector, mode;
    size_t size;
    String name;
    cdutils::DirEntry * dir;
};

#endif
