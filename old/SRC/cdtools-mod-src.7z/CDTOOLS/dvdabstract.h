/*
 *  PSX-Tools Bundle Pack
 *  Copyright (C) 2002-2003 Nicolas "Pixel" Noble
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/* $Id: dvdabstract.h,v 1.1 2005/11/02 21:34:02 pixel Exp $ */

#ifndef __DVDABSTRACT_H__
#define __DVDABSTRACT_H__

#include "Exceptions.h"
#include "Handle.h"
#include "cdutils.h"

class dvdabstract : public Handle {
  public:
      dvdabstract(Handle * h, int = MODE2_FORM1);
    virtual off_t seek(off_t, int = SEEK_SET) throw (GeneralException);
    virtual off_t tell() const;
    virtual ssize_t read(void * buf, size_t count) throw (GeneralException);
    virtual ssize_t write(const void * buf, size_t count) throw (GeneralException);

    virtual bool CanRead() const { return r->CanRead(); }
    virtual bool CanWrite() const { return r->CanWrite(); }
    virtual bool CanSeek() const { return true; }
    virtual String GetName() const { return "DVD abstraction of " + r->GetName(); }
    virtual time_t GetModif() const { return r->GetModif(); }
    virtual bool CanWatch() const { return false; }
    virtual void Flush() {
		//r->Flush();
	}
    virtual void SetZ(int = 9) throw (GeneralException) { throw GeneralException("Can't SetZ() a dvdabstract."); }
    virtual int Dup() const throw (GeneralException) { throw GeneralException("Can't Dup() a dvdabstract."); }

  private:
    Handle * r;
    off_t v;
    int m;

    void write_sector(const char * buf, int sector) throw (GeneralException);
    void read_sector(char * buf, int sector);
};

#endif
