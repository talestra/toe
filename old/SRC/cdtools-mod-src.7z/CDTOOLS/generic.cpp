/* 
 *  PSX-Tools Bundle Pack 
 *  Copyright (C) 2002 Nicolas "Pixel" Noble 
 *  
 *  This program is free software; you can redistribute it and/or modify 
 *  it under the terms of the GNU General Public License as published by 
 *  the Free Software Foundation; either version 2 of the License, or 
 *  (at your option) any later version. 
 * 
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of 
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
 *  GNU General Public License for more details. 
 * 
 *  You should have received a copy of the GNU General Public License 
 *  along with this program; if not, write to the Free Software 
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

#include <stdio.h>
#include <stdarg.h>

#include "String.h"

char verbosity = 0;

char * heads[] = {"EE", "--", "WW", "II"};

void printm(int level, String m, ...) {
    va_list ap;
    
    if (verbosity < level) {
	return;
    }
    
    if (level >= 0) {
	fprintf(stderr, "(%s) ", heads[level]);
    }

    va_start(ap, m);    
    vfprintf(stderr, m.to_charp(), ap);
    va_end(ap);
}

char ** split(char * s, char t) {
    static char * p[100];
    int i;
    
    for (i = 1, p[0] = s; *s; s++) {
	if (*s == t) {
	    *s = 0;
	    p[i++] = s + 1;
	}
    }
    p[i] = 0;
    
    return p;
}
