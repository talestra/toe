/*
 *  PSX-Tools Bundle Pack
 *  Copyright (C) 2002-2003 Nicolas "Pixel" Noble
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/* $Id: isobuilder.h,v 1.14 2006/07/17 16:11:25 pixel Exp $ */

#ifndef __ISOBUILDER_H__
#define __ISOBUILDER_H__

#include "Handle.h"
#include "cdutils.h"
#include "yazedc.h"

class isobuilder : public Base {
public:
	struct Date {
		int year, month, day, hour, minute, second, hundredths, offset;
		void dump(Byte * data);
		Date(int = 0);
		Date(Byte * data);
	};

	struct PVD {
		String sysid, volid;
		String volsetid, pubid, prepid, appid;
		String copyright, abstract, biblio;
		Date volcreat, modif, volexp, voleff;
		Byte appdata[512];
	};

	class DirTree : public Base {
	public:
		DirTree(DirTree * father, bool dir = true);
		virtual ~DirTree();
		void fromdir(cdutils::DirEntry *);
		void dumpdirs(isobuilder *) throw (GeneralException);
		int buildpath(Byte * data, int size, bool bigendian = false);
		bool isdir();
		void setbasicsxa();
		int sector;
		int size;
		bool hidden;
		bool hardhide;
		String name;
		Date creation;
		bool have_xa, xa_dir, xa_audio, xa_str, xa_xa, xa_form1;
		int buildentry(Byte * buffer, int spaceleft, bool put_xa = true);
		int mode;
		DirTree * Father();
		DirTree * Child();
		DirTree * Brother();
		DirTree * Find(const String &);
		bool catdot1;
	private:
		int buildpath_r(Byte * data, int size, int current_level, int level_to_dump, bool bigendian) throw (GeneralException);
		int maxlevel(int current_level = 1);
		DirTree * father, * child, * brother;
		bool dir;
		int node;
		int numerate(int);
	};

	isobuilder(Handle * w, int mode = MODE2_FORM1);
	~isobuilder();
	void foreword(cdutils *);
	void foreword(Handle * forewords, int mode = MODE_RAW);
	void foreword(Byte * forewords, int mode = MODE_RAW);
	int getdispsect();
	int putfile(Handle * file, int mode = -1, int sector = -1);
	int putdata(Byte * data, size_t size, int mode = -1, int sector = -1);
	int createsector(Byte * data, int mode = -1, int sector = -1, int FN = -1, int CN = -1, int SM = -1, int CI = -1);
	int createsector(Handle * file, int mode = -1, int sector = -1, int FN = -1, int CN = -1, int SM = -1, int CI = -1);
	void setEOF();
	void clearEOF();
	DirTree * setbasics(PVD pvd, int rootsize = 1, int ptsize = 1, int nvd = 1, int rootsect = -1) throw (GeneralException);
	DirTree * createdir(DirTree *, const String & _name, int size = 1, cdutils::DirEntry * = 0, int mode = -1) throw (GeneralException);
	DirTree * createfile(DirTree *, Handle * file, const String & _name, cdutils::DirEntry * = 0, int mode = -1) throw (GeneralException);
	void copydir(DirTree *, cdutils *, cdutils::DirEntry *, int mode = -1, const String & checkdir = "");
	static PVD createpvd(Handle *);
	static PVD createpvd(cdutils *);
	static PVD createpvd(Byte *);
	void close(Handle * cue = 0, int mode = -1, int nsects = -1) throw (GeneralException);

	int sector, nsectors;
	int lastdispsect;
	bool catdot1;
	int padding;

private:
	Handle * w;
	int sub_EOF, sub_EOR;
	bool basics;
	PVD pvd;
	int rootsize, ptsize, nvd, ptsect, rootsect;
	DirTree * root;
	yazedc yazedc_o;
	bool closed;
	int dmode;
};

#endif
