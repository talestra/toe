This is a modification of the great library CD-TOOLS
made by Nicolas "Pixel" Noble. (http://www.nobis-crew.org/)

Modified by Carlos Ballesteros Velasco (soywiz) for
Translation of Tales of Eternia to Spanish Project
(http://www.tales-tra.com/)